import os
from dataclasses import dataclass
from dotenv import load_dotenv
load_dotenv()
@dataclass(frozen=True)
class Settings:
    agent_count:int=int(os.getenv("AGENT_COUNT","300"))
    execution_mode:str=os.getenv("EXECUTION_MODE","paper").lower()
    scan_interval:float=float(os.getenv("SCAN_INTERVAL_SECONDS","10"))
    max_http:int=int(os.getenv("MAX_CONCURRENT_HTTP","20"))
    defillama_key:str|None=os.getenv("DEFILLAMA_API_KEY") or None
    coingecko_key:str|None=os.getenv("COINGECKO_API_KEY") or None
    solana_rpc:str=os.getenv("SOLANA_RPC_URL","https://api.mainnet-beta.solana.com")
    redis_url:str=os.getenv("REDIS_URL","redis://localhost:6379/0")
    database_url:str=os.getenv("DATABASE_URL","postgresql://trader:trader@localhost:5432/trading_floor")
    max_position_usd:float=float(os.getenv("MAX_POSITION_USD","100"))
    max_daily_loss_usd:float=float(os.getenv("MAX_DAILY_LOSS_USD","250"))
    min_liquidity_usd:float=float(os.getenv("MIN_LIQUIDITY_USD","25000"))
    min_confidence:float=float(os.getenv("MIN_SIGNAL_CONFIDENCE","0.70"))
