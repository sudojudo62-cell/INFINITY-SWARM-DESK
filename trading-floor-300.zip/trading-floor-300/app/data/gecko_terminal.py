import aiohttp
class GeckoTerminalClient:
    def __init__(self,api_key=None,timeout=20):
        self.api_key=api_key; self.timeout=aiohttp.ClientTimeout(total=timeout); self.base="https://pro-api.coingecko.com/api/v3" if api_key else "https://api.geckoterminal.com/api/v2"
    def headers(self): return {"x-cg-pro-api-key":self.api_key} if self.api_key else {}
    async def trending_pools(self,duration="24h",page=1):
        url=f"{self.base}/onchain/networks/trending_pools"
        async with aiohttp.ClientSession(timeout=self.timeout,headers=self.headers()) as s:
            async with s.get(url,params={"duration":duration,"page":page,"include":"base_token,quote_token,dex"}) as r: r.raise_for_status(); return await r.json()
    async def new_pools(self,page=1):
        url=f"{self.base}/onchain/networks/new_pools"
        async with aiohttp.ClientSession(timeout=self.timeout,headers=self.headers()) as s:
            async with s.get(url,params={"page":page,"include":"base_token,quote_token,dex"}) as r: r.raise_for_status(); return await r.json()
