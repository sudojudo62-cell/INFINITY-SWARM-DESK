# Provider notes

DefiLlama has an official TypeScript/JavaScript SDK and API. GeckoTerminal is exposed through CoinGecko's onchain API, including pools, tokens, trades, OHLCV, new pools and trending pools. Metaplex enrichment is implemented through a DAS-compatible JSON-RPC adapter.

For production, use provider-approved API plans and centralized caching/rate limiting rather than 300 independent clients.
