import asyncio,json
from .config import Settings
from .data.hub import MarketDataHub
from .orchestrator import TradingFloor
async def main():
    s=Settings(); print(f"Starting {s.agent_count} parallel agents; mode={s.execution_mode}"); floor=TradingFloor(s,MarketDataHub(s))
    while True:
        try: print(json.dumps(await floor.cycle()))
        except Exception as e: print("[cycle]",e)
        await asyncio.sleep(s.scan_interval)
if __name__=="__main__": asyncio.run(main())
