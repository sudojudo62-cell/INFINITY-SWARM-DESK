import asyncio,random
class SwarmAgent:
    def __init__(self,agent_id,strategy,settings): self.agent_id=agent_id; self.strategy=strategy; self.settings=settings; self.rng=random.Random(agent_id)
    async def evaluate(self,assets):
        await asyncio.sleep(0)
        return [s for a in assets if (s:=self.strategy.evaluate(self.agent_id,a,self.rng)) and s.confidence>=self.settings.min_confidence]
