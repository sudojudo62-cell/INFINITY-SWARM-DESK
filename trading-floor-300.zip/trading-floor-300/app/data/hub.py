from .gecko_terminal import GeckoTerminalClient
from .defillama import DefiLlamaClient
from .metaplex import MetaplexDASClient
from ..types import AssetSnapshot
class MarketDataHub:
    def __init__(self,settings):
        self.gecko=GeckoTerminalClient(settings.coingecko_key); self.llama=DefiLlamaClient(settings.defillama_key); self.metaplex=MetaplexDASClient(settings.solana_rpc); self.snapshot=[]
    async def refresh(self):
        try:self.snapshot=self._parse((await self.gecko.trending_pools()))
        except Exception as e: print("[data] GeckoTerminal:",e)
        return self.snapshot
    @staticmethod
    def _parse(payload):
        out=[]; inc={x.get("id"):x for x in payload.get("included",[])}
        for p in payload.get("data",[]):
            a=p.get("attributes",{}); ref=p.get("relationships",{}).get("base_token",{}).get("data",{}); t=inc.get(ref.get("id"),{}).get("attributes",{})
            try: out.append(AssetSnapshot(p.get("id","").split("_",1)[0],t.get("address", ""),t.get("symbol", "UNKNOWN"),float(a.get("base_token_price_usd") or 0),float(a.get("reserve_in_usd") or a.get("liquidity_usd") or 0),float(a.get("volume_usd",{}).get("h24") or 0),float(a.get("price_change_percentage",{}).get("h1") or 0),float(a.get("price_change_percentage",{}).get("h24") or 0),{"pool":a.get("address")}))
            except (TypeError,ValueError): pass
        return out
