# Trading Floor — 300-Agent Swarm

A starter architecture for running 300 independent strategy agents concurrently against a shared market-data snapshot.

```text
DefiLlama ─┐
GeckoTerm. ├─> Market Data Hub -> Redis/Event Bus -> 300 Agents -> Risk/Consensus -> Execution Gate
Metaplex ──┘
```

The 300 agents do **not** independently hammer APIs. Collectors fetch/normalize data once, then fan out a shared snapshot to the swarm. This avoids multiplying provider traffic by 300.

Default execution is **paper**. Real-money execution is intentionally not enabled in this starter build; keep wallet/private-key handling outside the AI/swarm process.

## Run

```bash
cp .env.example .env
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m app.main
```

Or:

```bash
docker compose up --build
```

## Test 300-way concurrency without external APIs

```bash
python scripts/test_swarm.py
```

## Main components

- `app/data/gecko_terminal.py` — GeckoTerminal/CoinGecko onchain adapter
- `app/data/defillama.py` — DefiLlama adapter
- `app/data/metaplex.py` — Metaplex DAS JSON-RPC adapter
- `app/data/hub.py` — shared data fanout
- `app/strategies.py` — six strategy families
- `app/agent.py` — swarm worker
- `app/orchestrator.py` — parallel execution coordinator
- `app/risk.py` — hard risk gates
- `app/execution.py` — paper execution gate

This is a research/paper-trading foundation and does not guarantee profit.
