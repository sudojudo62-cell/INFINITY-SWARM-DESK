class RiskEngine:
    def __init__(self,s): self.s=s
    def validate(self,x):
        if x.proposed_notional_usd>self.s.max_position_usd:return False,"size"
        if x.asset.liquidity_usd<self.s.min_liquidity_usd:return False,"liquidity"
        if x.confidence<self.s.min_confidence:return False,"confidence"
        return x.action in {"BUY","SELL"},"policy"
