import uuid
from datetime import datetime,timezone
class PaperExecution:
    async def execute(self,s): return {"order_id":str(uuid.uuid4()),"timestamp":datetime.now(timezone.utc).isoformat(),"mode":"paper","agent_id":s.agent_id,"strategy":s.strategy,"action":s.action,"symbol":s.asset.symbol,"address":s.asset.address,"notional_usd":s.proposed_notional_usd,"price_usd":s.asset.price_usd}
class ExecutionGate:
    def __init__(self,mode):
        if mode!="paper": raise RuntimeError("Only paper execution is enabled in this starter build.")
        self.executor=PaperExecution()
    async def submit(self,s): return await self.executor.execute(s)
