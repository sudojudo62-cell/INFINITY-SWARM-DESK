from abc import ABC,abstractmethod
from .types import Signal
class Strategy(ABC):
    name="base"
    @abstractmethod
    def evaluate(self,agent_id,asset,rng): ...
def sig(i,n,a,c,r): return Signal(i,n,"BUY",a,min(1,c),r,25,.04,.08)
class Momentum(Strategy):
    name="momentum"
    def evaluate(self,i,a,rng):
        if a.price_change_1h>2 and a.volume_24h_usd>50000:return sig(i,self.name,a,.65+a.price_change_1h/100+rng.random()*.08,"positive 1h momentum with volume support")
class MeanReversion(Strategy):
    name="mean_reversion"
    def evaluate(self,i,a,rng):
        if a.price_change_1h<-4 and a.price_change_24h>-12:return sig(i,self.name,a,.65+abs(a.price_change_1h)/100+rng.random()*.05,"short-term drawdown")
class Liquidity(Strategy):
    name="liquidity"
    def evaluate(self,i,a,rng):
        if a.liquidity_usd>=100000 and a.volume_24h_usd>=100000:return sig(i,self.name,a,.72+rng.random()*.15,"liquidity and volume")
class Breakout(Strategy):
    name="breakout"
    def evaluate(self,i,a,rng):
        if a.price_change_24h>10 and a.price_change_1h>3:return sig(i,self.name,a,.70+rng.random()*.18,"multi-timeframe breakout")
class Volatility(Strategy):
    name="volatility"
    def evaluate(self,i,a,rng):
        if abs(a.price_change_1h)>5 and a.volume_24h_usd>75000:return sig(i,self.name,a,.68+rng.random()*.18,"high volatility and volume")
class Conservative(Strategy):
    name="conservative"
    def evaluate(self,i,a,rng):
        if a.liquidity_usd>250000 and abs(a.price_change_24h)<15:return sig(i,self.name,a,.71+rng.random()*.12,"liquidity-first setup")
STRATEGIES=[Momentum(),MeanReversion(),Liquidity(),Breakout(),Volatility(),Conservative()]
