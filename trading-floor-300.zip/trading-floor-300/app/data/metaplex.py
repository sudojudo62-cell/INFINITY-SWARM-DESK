import aiohttp
class MetaplexDASClient:
    def __init__(self,rpc_url,timeout=20): self.rpc_url=rpc_url; self.timeout=aiohttp.ClientTimeout(total=timeout)
    async def get_asset(self,asset_id):
        payload={"jsonrpc":"2.0","id":1,"method":"getAsset","params":{"id":asset_id}}
        async with aiohttp.ClientSession(timeout=self.timeout) as s:
            async with s.post(self.rpc_url,json=payload) as r: r.raise_for_status(); return await r.json()
    async def search_assets(self,owner_address=None,creator_address=None,limit=100):
        p={"limit":limit}
        if owner_address:p["ownerAddress"]=owner_address
        if creator_address:p["creatorAddress"]=creator_address
        payload={"jsonrpc":"2.0","id":1,"method":"searchAssets","params":p}
        async with aiohttp.ClientSession(timeout=self.timeout) as s:
            async with s.post(self.rpc_url,json=payload) as r: r.raise_for_status(); return await r.json()
