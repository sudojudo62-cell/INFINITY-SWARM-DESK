import aiohttp
class DefiLlamaClient:
    def __init__(self,api_key=None,timeout=20): self.api_key=api_key; self.timeout=aiohttp.ClientTimeout(total=timeout)
    async def protocols(self):
        async with aiohttp.ClientSession(timeout=self.timeout) as s:
            async with s.get("https://api.llama.fi/protocols") as r: r.raise_for_status(); return await r.json()
    async def token_prices(self,coins):
        url="https://coins.llama.fi/prices/current/"+",".join(coins)
        headers={"x-api-key":self.api_key} if self.api_key else {}
        async with aiohttp.ClientSession(timeout=self.timeout,headers=headers) as s:
            async with s.get(url) as r: r.raise_for_status(); return await r.json()
