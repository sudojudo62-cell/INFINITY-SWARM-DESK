import asyncio
from .agent import SwarmAgent
from .execution import ExecutionGate
from .risk import RiskEngine
from .strategies import STRATEGIES
class TradingFloor:
    def __init__(self,settings,hub):
        self.settings=settings; self.hub=hub; self.risk=RiskEngine(settings); self.execution=ExecutionGate(settings.execution_mode)
        self.agents=[SwarmAgent(f"agent-{i+1:03d}",STRATEGIES[i%len(STRATEGIES)],settings) for i in range(settings.agent_count)]
    async def cycle(self):
        assets=await self.hub.refresh()
        results=await asyncio.gather(*(a.evaluate(assets) for a in self.agents),return_exceptions=True)
        signals=[s for r in results if not isinstance(r,Exception) for s in r]
        approved=[s for s in signals if self.risk.validate(s)[0]]
        executions=await asyncio.gather(*(self.execution.submit(s) for s in approved),return_exceptions=True)
        return {"agents":len(self.agents),"assets":len(assets),"signals":len(signals),"approved":len(approved),"executions":[x for x in executions if not isinstance(x,Exception)]}
