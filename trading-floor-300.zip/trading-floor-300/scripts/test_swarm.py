import asyncio
from app.config import Settings
from app.agent import SwarmAgent
from app.strategies import STRATEGIES
from app.types import AssetSnapshot
async def main():
    s=Settings(); a=AssetSnapshot("solana","TEST","TEST",1,500000,1000000,5,15); agents=[SwarmAgent(f"agent-{i+1:03d}",STRATEGIES[i%len(STRATEGIES)],s) for i in range(300)]; r=await asyncio.gather(*(x.evaluate([a]) for x in agents)); print("agents:",len(r)); print("signals:",sum(map(len,r)))
if __name__=="__main__": asyncio.run(main())
