from dataclasses import dataclass, field
from typing import Any
@dataclass
class AssetSnapshot:
    chain:str; address:str; symbol:str; price_usd:float; liquidity_usd:float; volume_24h_usd:float; price_change_1h:float; price_change_24h:float; metadata:dict[str,Any]=field(default_factory=dict)
@dataclass
class Signal:
    agent_id:str; strategy:str; action:str; asset:AssetSnapshot; confidence:float; rationale:str; proposed_notional_usd:float; stop_loss_pct:float; take_profit_pct:float
